tag @s add bt_ctrl_ray_hit
# Si es Bloque de Topografía, derivar a su inicialización
execute if items entity @s weapon.mainhand minecraft:note_block[custom_data~{builder_tables_surveyor:1b}] run function builder_tables_generated:surveyor/placed
execute if items entity @s weapon.mainhand minecraft:note_block[custom_data~{builder_tables_surveyor:1b}] run return 1
execute if items entity @s weapon.offhand minecraft:note_block[custom_data~{builder_tables_surveyor:1b}] run function builder_tables_generated:surveyor/placed
execute if items entity @s weapon.offhand minecraft:note_block[custom_data~{builder_tables_surveyor:1b}] run return 1
summon minecraft:marker ~ ~ ~ {Tags:["bt_plan_anchor"]}
tellraw @s {"text":"[Builder Tables] Bloque de Planificación registrado. Haz clic para abrir el catálogo.","color":"aqua"}
