execute unless score @s bt_surv_step matches 1 run function builder_tables_generated:surveyor/set_corner_1
execute if score @s bt_surv_step matches 1 run function builder_tables_generated:surveyor/set_corner_2
