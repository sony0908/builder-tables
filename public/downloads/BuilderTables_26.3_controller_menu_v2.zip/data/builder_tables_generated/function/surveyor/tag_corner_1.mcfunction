tag @s add bt_surv_c1
particle minecraft:happy_villager ~ ~ ~ 0.3 0.3 0.3 0 10
