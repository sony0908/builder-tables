execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run tellraw @s {"text":"[Topografía] Falta marcar la Esquina 1 con la Cinta de Topógrafo.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run return 0
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run tellraw @s {"text":"[Topografía] Falta marcar la Esquina 2 con la Cinta de Topógrafo.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run return 0
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run structure save builder_tables:plano_capturado ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1]
playsound minecraft:entity.player.levelup player @s ~ ~ ~ 1 1
tellraw @s [{"text":"[Builder Tables] ","color":"gold","bold":true},{"text":"¡Plano escaneado y guardado con éxito!","color":"green","bold":true}]
tellraw @s [{"text":"Archivo generado en tu mundo: ","color":"gray"},{"text":"world/generated/builder_tables/structures/plano_capturado.nbt","color":"aqua"}]
tellraw @s {"text":"Puedes arrastrar este archivo .NBT a la web de Builder Tables para cambiarle bloques, asignarle precio o generar un datapack.","color":"yellow"}
