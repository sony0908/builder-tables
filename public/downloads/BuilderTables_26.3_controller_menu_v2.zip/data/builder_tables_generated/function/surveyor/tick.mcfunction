scoreboard players enable @a bt_surv_copy
scoreboard players enable @a bt_surv_demo_ask
scoreboard players enable @a bt_surv_demo_exec
scoreboard players enable @a bt_surv_clear
scoreboard players enable @a bt_give_tape
execute as @a[scores={bt_give_tape=1..}] run function builder_tables:give_tape
scoreboard players reset @a[scores={bt_give_tape=1..}] bt_give_tape
execute as @a[scores={bt_tape_used=1..}] if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[custom_data~{builder_tables_surveyor_tape:1b}] run function builder_tables_generated:surveyor/use_tape
execute as @a[scores={bt_tape_used=1..}] if items entity @s weapon.offhand minecraft:carrot_on_a_stick[custom_data~{builder_tables_surveyor_tape:1b}] run function builder_tables_generated:surveyor/use_tape
scoreboard players reset @a[scores={bt_tape_used=1..}] bt_tape_used
execute as @a[scores={bt_surv_copy=1..}] run function builder_tables_generated:surveyor/copy_nbt
scoreboard players reset @a[scores={bt_surv_copy=1..}] bt_surv_copy
execute as @a[scores={bt_surv_demo_ask=1..}] run function builder_tables_generated:surveyor/open_demo_confirm
scoreboard players reset @a[scores={bt_surv_demo_ask=1..}] bt_surv_demo_ask
execute as @a[scores={bt_surv_demo_exec=1..}] run function builder_tables_generated:surveyor/execute_demo
scoreboard players reset @a[scores={bt_surv_demo_exec=1..}] bt_surv_demo_exec
execute as @a[scores={bt_surv_clear=1..}] run function builder_tables_generated:surveyor/clear_selection
scoreboard players reset @a[scores={bt_surv_clear=1..}] bt_surv_clear
execute as @e[type=minecraft:marker,tag=bt_surv_c1] at @s run particle minecraft:happy_villager ~ ~0.5 ~ 0.2 0.2 0 3
execute as @e[type=minecraft:marker,tag=bt_surv_c2] at @s run particle minecraft:wax_on ~ ~0.5 ~ 0.2 0.2 0 3
