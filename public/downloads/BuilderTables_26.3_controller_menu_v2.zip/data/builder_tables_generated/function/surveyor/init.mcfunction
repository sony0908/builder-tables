scoreboard objectives add bt_surv_copy trigger
scoreboard objectives add bt_surv_demo_ask trigger
scoreboard objectives add bt_surv_demo_exec trigger
scoreboard objectives add bt_surv_clear trigger
scoreboard objectives add bt_give_tape trigger
scoreboard objectives add bt_surv_step dummy
scoreboard objectives add bt_surv_blocks dummy
scoreboard objectives add bt_surv_payout dummy
scoreboard objectives add bt_tape_used minecraft.used:minecraft.carrot_on_a_stick
recipe give @a builder_tables:surveyor_block
recipe give @a builder_tables:surveyor_tape
recipe give @a builder_tables:planning_block
recipe give @a builder_tables:bank_card
