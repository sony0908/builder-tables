tag @s add bt_surv_c2
particle minecraft:wax_on ~ ~ ~ 0.3 0.3 0.3 0 15
