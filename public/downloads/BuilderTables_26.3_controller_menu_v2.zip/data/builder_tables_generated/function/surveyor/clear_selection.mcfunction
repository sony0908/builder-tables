kill @e[type=minecraft:marker,tag=bt_surv_c1]
kill @e[type=minecraft:marker,tag=bt_surv_c2]
scoreboard players set @s bt_surv_step 0
playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.8 1.2
tellraw @s {"text":"[Topografía] Selección de esquinas reiniciada.","color":"gray"}
