kill @e[type=minecraft:marker,tag=bt_surv_c2]
execute anchored eyes positioned ^ ^ ^3.5 summon minecraft:marker run function builder_tables_generated:surveyor/tag_corner_2
scoreboard players set @s bt_surv_step 2
playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.8 1.4
tellraw @s [{"text":"[Topografía] ","color":"aqua","bold":true},{"text":"Esquina 2 fijada. ","color":"green","bold":true},{"text":"¡Área delimitada sin límites de tamaño! Haz clic derecho en el Bloque de Topografía para Copiar Plano o Demoler y Vender.","color":"gold"}]
