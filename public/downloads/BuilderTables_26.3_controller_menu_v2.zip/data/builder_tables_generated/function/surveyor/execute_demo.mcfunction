execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run return 0
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run return 0
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace #minecraft:mineable/pickaxe
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace #minecraft:mineable/shovel
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace #minecraft:mineable/axe
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace #minecraft:mineable/hoe
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace stone
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace dirt
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace deepslate
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace gravel
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run fill ~ ~ ~ @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] air replace sand
scoreboard players set @s bt_surv_payout 64
scoreboard players operation @s bt_bank += @s bt_surv_payout
give @s minecraft:emerald 16
playsound minecraft:entity.generic.explode player @s ~ ~ ~ 1 0.8
playsound minecraft:block.anvil.destroy player @s ~ ~ ~ 1 1
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run particle minecraft:explosion ~ ~ ~ 2 2 2 0 10
execute at @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run particle minecraft:poof ~ ~ ~ 2 2 2 0 15
tellraw @s [{"text":"[Topografía] ","color":"gold","bold":true},{"text":"¡Área demolida y allanada exitosamente!","color":"green","bold":true}]
tellraw @s [{"text":"Se han liquidado los materiales al ","color":"yellow"},{"text":"75% (3/4) de su valor","color":"gold","bold":true},{"text":". Esmeraldas añadidas a tu saldo y bolsa.","color":"yellow"}]
function builder_tables_generated:surveyor/clear_selection
