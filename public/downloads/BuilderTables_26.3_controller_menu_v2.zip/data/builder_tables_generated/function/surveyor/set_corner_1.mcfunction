kill @e[type=minecraft:marker,tag=bt_surv_c1]
execute anchored eyes positioned ^ ^ ^3.5 summon minecraft:marker run function builder_tables_generated:surveyor/tag_corner_1
scoreboard players set @s bt_surv_step 1
playsound minecraft:block.note_block.bell player @s ~ ~ ~ 1 1.6
tellraw @s [{"text":"[Topografía] ","color":"aqua","bold":true},{"text":"Esquina 1 fijada. ","color":"green","bold":true},{"text":"Haz clic derecho en la esquina opuesta para fijar la Esquina 2.","color":"yellow"}]
