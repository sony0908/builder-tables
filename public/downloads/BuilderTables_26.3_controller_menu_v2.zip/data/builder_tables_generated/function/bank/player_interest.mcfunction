# Nivel 1: Saldo hasta 25,000 esmeraldas -> 10% diario (dividido por 10)
execute if score @s bt_bank matches ..25000 run scoreboard players operation @s bt_interest = @s bt_bank
execute if score @s bt_bank matches ..25000 run scoreboard players operation @s bt_interest /= #ten bt_interest_math
# Nivel 2: Saldo mayor a 25,000 esmeraldas -> 2,500 base (10% de 25k) + 1% del excedente
execute if score @s bt_bank matches 25001.. run scoreboard players operation @s bt_temp = @s bt_bank
execute if score @s bt_bank matches 25001.. run scoreboard players operation @s bt_temp -= #tier1_limit bt_interest_math
execute if score @s bt_bank matches 25001.. run scoreboard players operation @s bt_temp /= #hundred bt_interest_math
execute if score @s bt_bank matches 25001.. run scoreboard players operation @s bt_interest = #tier1_max bt_interest_math
execute if score @s bt_bank matches 25001.. run scoreboard players operation @s bt_interest += @s bt_temp
# Tope maximo global (5,000 esmeraldas diarias)
execute if score @s bt_interest matches 5001.. run scoreboard players operation @s bt_interest = #cap bt_interest_math
# Aplicar interes al saldo y notificar al jugador
execute if score @s bt_interest matches 1.. run scoreboard players operation @s bt_bank += @s bt_interest
execute if score @s bt_interest matches 1.. run playsound minecraft:block.amethyst_block.chime player @s ~ ~ ~ 0.8 1.2
execute if score @s bt_interest matches 1.. run title @s actionbar [{"text":"+ ","color":"green","bold":true},{"score":{"name":"@s","objective":"bt_interest"},"color":"green","bold":true},{"text":" esmeraldas en intereses bancarios","color":"gold"}]
