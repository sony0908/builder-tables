# Cambiar al siguiente paquete de planos desde la interfaz GUI
scoreboard players add #active_pack bt_pack_index 1
execute if score #active_pack bt_pack_index > #installed_packs bt_pack_count run scoreboard players set #active_pack bt_pack_index 1
function #builder_tables:menu/open_pack_by_index
execute if score #installed_packs bt_pack_count matches 1 run title @s actionbar {"text":"Solo hay 1 paquete de planos instalado","color":"yellow"}
