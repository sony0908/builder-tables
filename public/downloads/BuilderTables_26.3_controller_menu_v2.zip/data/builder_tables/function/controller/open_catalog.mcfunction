# Abrir catalogo directamente en la interfaz GUI (sin chat)
scoreboard players set #installed_packs bt_pack_count 0
function #builder_tables:menu/register_pack
execute unless score #active_pack bt_pack_index matches 1.. run scoreboard players set #active_pack bt_pack_index 1
execute if score #active_pack bt_pack_index > #installed_packs bt_pack_count run scoreboard players set #active_pack bt_pack_index 1
function #builder_tables:menu/open_pack_by_index
execute if score #installed_packs bt_pack_count matches ..0 run dialog show @s builder_tables:catalogo
