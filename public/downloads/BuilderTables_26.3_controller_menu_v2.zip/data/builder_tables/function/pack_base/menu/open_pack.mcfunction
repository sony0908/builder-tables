# Abrir catalogo base si coincide con el indice activo
execute if score #active_pack bt_pack_index = #pack_base bt_pack_index run dialog show @s builder_tables:catalogo
