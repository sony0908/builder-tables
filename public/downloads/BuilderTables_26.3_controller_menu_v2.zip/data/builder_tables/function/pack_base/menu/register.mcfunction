# Registrar presencia y asignar indice al paquete base
scoreboard players add #installed_packs bt_pack_count 1
scoreboard players operation #pack_base bt_pack_index = #installed_packs bt_pack_count
