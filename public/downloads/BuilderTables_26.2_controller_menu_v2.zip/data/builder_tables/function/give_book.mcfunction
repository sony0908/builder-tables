# Alias de compatibilidad: el antiguo catálogo en libro fue retirado.
# Los libros se reservan para recetas; este comando ahora entrega el controlador.
function builder_tables:give_controller