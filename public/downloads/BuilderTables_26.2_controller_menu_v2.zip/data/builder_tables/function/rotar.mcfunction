# Procesa el boton [ ROTAR 90° ] de cualquier plano abierto
execute as @a[scores={bt_rot=1..}] run scoreboard players add @s bt_rot_state 1
execute as @a[scores={bt_rot=1..}] if score @s bt_rot_state matches 4.. run scoreboard players set @s bt_rot_state 0
execute as @a[scores={bt_rot=1..}] if score @s bt_rot_state matches 0 run title @s actionbar {"text":"Rotación: 0°","color":"aqua"}
execute as @a[scores={bt_rot=1..}] if score @s bt_rot_state matches 1 run title @s actionbar {"text":"Rotación: 90°","color":"aqua"}
execute as @a[scores={bt_rot=1..}] if score @s bt_rot_state matches 2 run title @s actionbar {"text":"Rotación: 180°","color":"aqua"}
execute as @a[scores={bt_rot=1..}] if score @s bt_rot_state matches 3 run title @s actionbar {"text":"Rotación: 270°","color":"aqua"}
scoreboard players reset @a[scores={bt_rot=1..}] bt_rot
