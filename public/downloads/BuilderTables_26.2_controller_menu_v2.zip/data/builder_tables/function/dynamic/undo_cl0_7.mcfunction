# Deshace la última construcción de cl0_7 y devuelve el precio pagado.
execute unless entity @e[tag=bt_anchor_cl0_7] run tellraw @s {"text":"⚠ No hay ninguna construcción reciente de este plano para deshacer.","color":"red"}
execute if entity @e[tag=bt_anchor_cl0_7,tag=bt_rot0] at @e[tag=bt_anchor_cl0_7,tag=bt_rot0,limit=1] run fill ~ ~ ~ ~18 ~22 ~18 air replace
execute if entity @e[tag=bt_anchor_cl0_7,tag=bt_rot1] at @e[tag=bt_anchor_cl0_7,tag=bt_rot1,limit=1] run fill ~-18 ~ ~ ~ ~22 ~18 air replace
execute if entity @e[tag=bt_anchor_cl0_7,tag=bt_rot2] at @e[tag=bt_anchor_cl0_7,tag=bt_rot2,limit=1] run fill ~-18 ~ ~-18 ~ ~22 ~ air replace
execute if entity @e[tag=bt_anchor_cl0_7,tag=bt_rot3] at @e[tag=bt_anchor_cl0_7,tag=bt_rot3,limit=1] run fill ~ ~ ~-18 ~18 ~22 ~ air replace
execute if entity @e[tag=bt_anchor_cl0_7] run give @s minecraft:emerald 240
execute if entity @e[tag=bt_anchor_cl0_7] run tellraw @a {"text":"↩ Estructura 'cl0_7' retirada y 240 esmeraldas devueltas.","color":"yellow"}
kill @e[tag=bt_anchor_cl0_7]