# Deshace la última construcción de cl0_1 y devuelve el precio pagado.
execute unless entity @e[tag=bt_anchor_cl0_1] run tellraw @s {"text":"⚠ No hay ninguna construcción reciente de este plano para deshacer.","color":"red"}
execute if entity @e[tag=bt_anchor_cl0_1,tag=bt_rot0] at @e[tag=bt_anchor_cl0_1,tag=bt_rot0,limit=1] run fill ~ ~ ~ ~10 ~27 ~14 air replace
execute if entity @e[tag=bt_anchor_cl0_1,tag=bt_rot1] at @e[tag=bt_anchor_cl0_1,tag=bt_rot1,limit=1] run fill ~-14 ~ ~ ~ ~27 ~10 air replace
execute if entity @e[tag=bt_anchor_cl0_1,tag=bt_rot2] at @e[tag=bt_anchor_cl0_1,tag=bt_rot2,limit=1] run fill ~-10 ~ ~-14 ~ ~27 ~ air replace
execute if entity @e[tag=bt_anchor_cl0_1,tag=bt_rot3] at @e[tag=bt_anchor_cl0_1,tag=bt_rot3,limit=1] run fill ~ ~ ~-10 ~14 ~27 ~ air replace
execute if entity @e[tag=bt_anchor_cl0_1] run give @s minecraft:emerald 176
execute if entity @e[tag=bt_anchor_cl0_1] run tellraw @a {"text":"↩ Estructura 'cl0_1' retirada y 176 esmeraldas devueltas.","color":"yellow"}
kill @e[tag=bt_anchor_cl0_1]