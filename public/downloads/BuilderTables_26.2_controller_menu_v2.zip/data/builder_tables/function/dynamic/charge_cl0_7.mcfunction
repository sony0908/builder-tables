# Cobra 240 esmeraldas equivalentes; bloques de esmeralda = 9 esmeraldas.
execute if score @s bt_emeralds matches 240.. run clear @s minecraft:emerald 240
execute if score @s bt_emeralds matches 240.. run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 0 run clear @s minecraft:emerald 0
execute if score @s bt_emeralds matches 0 run clear @s minecraft:emerald_block 27
execute if score @s bt_emeralds matches 0 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 0 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 1 run clear @s minecraft:emerald 1
execute if score @s bt_emeralds matches 1 run clear @s minecraft:emerald_block 27
execute if score @s bt_emeralds matches 1 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 1 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 2 run clear @s minecraft:emerald 2
execute if score @s bt_emeralds matches 2 run clear @s minecraft:emerald_block 27
execute if score @s bt_emeralds matches 2 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 2 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 3 run clear @s minecraft:emerald 3
execute if score @s bt_emeralds matches 3 run clear @s minecraft:emerald_block 27
execute if score @s bt_emeralds matches 3 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 3 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 4 run clear @s minecraft:emerald 4
execute if score @s bt_emeralds matches 4 run clear @s minecraft:emerald_block 27
execute if score @s bt_emeralds matches 4 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 4 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 5 run clear @s minecraft:emerald 5
execute if score @s bt_emeralds matches 5 run clear @s minecraft:emerald_block 27
execute if score @s bt_emeralds matches 5 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 5 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 6 run clear @s minecraft:emerald 6
execute if score @s bt_emeralds matches 6 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 6 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 7 run clear @s minecraft:emerald 7
execute if score @s bt_emeralds matches 7 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 7 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 7 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 8 run clear @s minecraft:emerald 8
execute if score @s bt_emeralds matches 8 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 8 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 8 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 9 run clear @s minecraft:emerald 9
execute if score @s bt_emeralds matches 9 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 9 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 9 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 10 run clear @s minecraft:emerald 10
execute if score @s bt_emeralds matches 10 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 10 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 10 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 11 run clear @s minecraft:emerald 11
execute if score @s bt_emeralds matches 11 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 11 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 11 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 12 run clear @s minecraft:emerald 12
execute if score @s bt_emeralds matches 12 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 12 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 12 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 13 run clear @s minecraft:emerald 13
execute if score @s bt_emeralds matches 13 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 13 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 13 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 14 run clear @s minecraft:emerald 14
execute if score @s bt_emeralds matches 14 run clear @s minecraft:emerald_block 26
execute if score @s bt_emeralds matches 14 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 14 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 15 run clear @s minecraft:emerald 15
execute if score @s bt_emeralds matches 15 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 15 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 16 run clear @s minecraft:emerald 16
execute if score @s bt_emeralds matches 16 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 16 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 16 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 17 run clear @s minecraft:emerald 17
execute if score @s bt_emeralds matches 17 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 17 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 17 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 18 run clear @s minecraft:emerald 18
execute if score @s bt_emeralds matches 18 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 18 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 18 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 19 run clear @s minecraft:emerald 19
execute if score @s bt_emeralds matches 19 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 19 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 19 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 20 run clear @s minecraft:emerald 20
execute if score @s bt_emeralds matches 20 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 20 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 20 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 21 run clear @s minecraft:emerald 21
execute if score @s bt_emeralds matches 21 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 21 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 21 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 22 run clear @s minecraft:emerald 22
execute if score @s bt_emeralds matches 22 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 22 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 22 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 23 run clear @s minecraft:emerald 23
execute if score @s bt_emeralds matches 23 run clear @s minecraft:emerald_block 25
execute if score @s bt_emeralds matches 23 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 23 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 24 run clear @s minecraft:emerald 24
execute if score @s bt_emeralds matches 24 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 24 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 25 run clear @s minecraft:emerald 25
execute if score @s bt_emeralds matches 25 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 25 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 25 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 26 run clear @s minecraft:emerald 26
execute if score @s bt_emeralds matches 26 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 26 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 26 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 27 run clear @s minecraft:emerald 27
execute if score @s bt_emeralds matches 27 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 27 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 27 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 28 run clear @s minecraft:emerald 28
execute if score @s bt_emeralds matches 28 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 28 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 28 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 29 run clear @s minecraft:emerald 29
execute if score @s bt_emeralds matches 29 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 29 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 29 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 30 run clear @s minecraft:emerald 30
execute if score @s bt_emeralds matches 30 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 30 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 30 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 31 run clear @s minecraft:emerald 31
execute if score @s bt_emeralds matches 31 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 31 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 31 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 32 run clear @s minecraft:emerald 32
execute if score @s bt_emeralds matches 32 run clear @s minecraft:emerald_block 24
execute if score @s bt_emeralds matches 32 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 32 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 33 run clear @s minecraft:emerald 33
execute if score @s bt_emeralds matches 33 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 33 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 34 run clear @s minecraft:emerald 34
execute if score @s bt_emeralds matches 34 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 34 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 34 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 35 run clear @s minecraft:emerald 35
execute if score @s bt_emeralds matches 35 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 35 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 35 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 36 run clear @s minecraft:emerald 36
execute if score @s bt_emeralds matches 36 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 36 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 36 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 37 run clear @s minecraft:emerald 37
execute if score @s bt_emeralds matches 37 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 37 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 37 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 38 run clear @s minecraft:emerald 38
execute if score @s bt_emeralds matches 38 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 38 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 38 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 39 run clear @s minecraft:emerald 39
execute if score @s bt_emeralds matches 39 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 39 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 39 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 40 run clear @s minecraft:emerald 40
execute if score @s bt_emeralds matches 40 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 40 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 40 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 41 run clear @s minecraft:emerald 41
execute if score @s bt_emeralds matches 41 run clear @s minecraft:emerald_block 23
execute if score @s bt_emeralds matches 41 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 41 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 42 run clear @s minecraft:emerald 42
execute if score @s bt_emeralds matches 42 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 42 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 43 run clear @s minecraft:emerald 43
execute if score @s bt_emeralds matches 43 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 43 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 43 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 44 run clear @s minecraft:emerald 44
execute if score @s bt_emeralds matches 44 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 44 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 44 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 45 run clear @s minecraft:emerald 45
execute if score @s bt_emeralds matches 45 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 45 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 45 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 46 run clear @s minecraft:emerald 46
execute if score @s bt_emeralds matches 46 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 46 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 46 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 47 run clear @s minecraft:emerald 47
execute if score @s bt_emeralds matches 47 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 47 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 47 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 48 run clear @s minecraft:emerald 48
execute if score @s bt_emeralds matches 48 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 48 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 48 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 49 run clear @s minecraft:emerald 49
execute if score @s bt_emeralds matches 49 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 49 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 49 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 50 run clear @s minecraft:emerald 50
execute if score @s bt_emeralds matches 50 run clear @s minecraft:emerald_block 22
execute if score @s bt_emeralds matches 50 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 50 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 51 run clear @s minecraft:emerald 51
execute if score @s bt_emeralds matches 51 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 51 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 52 run clear @s minecraft:emerald 52
execute if score @s bt_emeralds matches 52 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 52 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 52 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 53 run clear @s minecraft:emerald 53
execute if score @s bt_emeralds matches 53 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 53 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 53 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 54 run clear @s minecraft:emerald 54
execute if score @s bt_emeralds matches 54 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 54 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 54 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 55 run clear @s minecraft:emerald 55
execute if score @s bt_emeralds matches 55 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 55 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 55 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 56 run clear @s minecraft:emerald 56
execute if score @s bt_emeralds matches 56 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 56 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 56 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 57 run clear @s minecraft:emerald 57
execute if score @s bt_emeralds matches 57 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 57 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 57 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 58 run clear @s minecraft:emerald 58
execute if score @s bt_emeralds matches 58 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 58 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 58 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 59 run clear @s minecraft:emerald 59
execute if score @s bt_emeralds matches 59 run clear @s minecraft:emerald_block 21
execute if score @s bt_emeralds matches 59 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 59 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 60 run clear @s minecraft:emerald 60
execute if score @s bt_emeralds matches 60 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 60 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 61 run clear @s minecraft:emerald 61
execute if score @s bt_emeralds matches 61 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 61 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 61 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 62 run clear @s minecraft:emerald 62
execute if score @s bt_emeralds matches 62 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 62 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 62 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 63 run clear @s minecraft:emerald 63
execute if score @s bt_emeralds matches 63 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 63 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 63 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 64 run clear @s minecraft:emerald 64
execute if score @s bt_emeralds matches 64 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 64 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 64 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 65 run clear @s minecraft:emerald 65
execute if score @s bt_emeralds matches 65 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 65 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 65 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 66 run clear @s minecraft:emerald 66
execute if score @s bt_emeralds matches 66 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 66 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 66 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 67 run clear @s minecraft:emerald 67
execute if score @s bt_emeralds matches 67 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 67 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 67 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 68 run clear @s minecraft:emerald 68
execute if score @s bt_emeralds matches 68 run clear @s minecraft:emerald_block 20
execute if score @s bt_emeralds matches 68 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 68 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 69 run clear @s minecraft:emerald 69
execute if score @s bt_emeralds matches 69 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 69 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 70 run clear @s minecraft:emerald 70
execute if score @s bt_emeralds matches 70 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 70 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 70 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 71 run clear @s minecraft:emerald 71
execute if score @s bt_emeralds matches 71 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 71 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 71 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 72 run clear @s minecraft:emerald 72
execute if score @s bt_emeralds matches 72 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 72 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 72 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 73 run clear @s minecraft:emerald 73
execute if score @s bt_emeralds matches 73 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 73 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 73 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 74 run clear @s minecraft:emerald 74
execute if score @s bt_emeralds matches 74 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 74 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 74 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 75 run clear @s minecraft:emerald 75
execute if score @s bt_emeralds matches 75 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 75 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 75 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 76 run clear @s minecraft:emerald 76
execute if score @s bt_emeralds matches 76 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 76 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 76 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 77 run clear @s minecraft:emerald 77
execute if score @s bt_emeralds matches 77 run clear @s minecraft:emerald_block 19
execute if score @s bt_emeralds matches 77 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 77 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 78 run clear @s minecraft:emerald 78
execute if score @s bt_emeralds matches 78 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 78 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 79 run clear @s minecraft:emerald 79
execute if score @s bt_emeralds matches 79 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 79 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 79 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 80 run clear @s minecraft:emerald 80
execute if score @s bt_emeralds matches 80 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 80 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 80 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 81 run clear @s minecraft:emerald 81
execute if score @s bt_emeralds matches 81 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 81 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 81 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 82 run clear @s minecraft:emerald 82
execute if score @s bt_emeralds matches 82 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 82 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 82 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 83 run clear @s minecraft:emerald 83
execute if score @s bt_emeralds matches 83 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 83 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 83 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 84 run clear @s minecraft:emerald 84
execute if score @s bt_emeralds matches 84 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 84 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 84 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 85 run clear @s minecraft:emerald 85
execute if score @s bt_emeralds matches 85 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 85 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 85 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 86 run clear @s minecraft:emerald 86
execute if score @s bt_emeralds matches 86 run clear @s minecraft:emerald_block 18
execute if score @s bt_emeralds matches 86 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 86 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 87 run clear @s minecraft:emerald 87
execute if score @s bt_emeralds matches 87 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 87 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 88 run clear @s minecraft:emerald 88
execute if score @s bt_emeralds matches 88 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 88 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 88 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 89 run clear @s minecraft:emerald 89
execute if score @s bt_emeralds matches 89 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 89 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 89 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 90 run clear @s minecraft:emerald 90
execute if score @s bt_emeralds matches 90 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 90 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 90 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 91 run clear @s minecraft:emerald 91
execute if score @s bt_emeralds matches 91 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 91 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 91 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 92 run clear @s minecraft:emerald 92
execute if score @s bt_emeralds matches 92 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 92 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 92 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 93 run clear @s minecraft:emerald 93
execute if score @s bt_emeralds matches 93 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 93 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 93 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 94 run clear @s minecraft:emerald 94
execute if score @s bt_emeralds matches 94 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 94 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 94 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 95 run clear @s minecraft:emerald 95
execute if score @s bt_emeralds matches 95 run clear @s minecraft:emerald_block 17
execute if score @s bt_emeralds matches 95 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 95 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 96 run clear @s minecraft:emerald 96
execute if score @s bt_emeralds matches 96 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 96 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 97 run clear @s minecraft:emerald 97
execute if score @s bt_emeralds matches 97 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 97 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 97 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 98 run clear @s minecraft:emerald 98
execute if score @s bt_emeralds matches 98 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 98 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 98 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 99 run clear @s minecraft:emerald 99
execute if score @s bt_emeralds matches 99 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 99 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 99 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 100 run clear @s minecraft:emerald 100
execute if score @s bt_emeralds matches 100 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 100 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 100 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 101 run clear @s minecraft:emerald 101
execute if score @s bt_emeralds matches 101 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 101 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 101 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 102 run clear @s minecraft:emerald 102
execute if score @s bt_emeralds matches 102 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 102 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 102 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 103 run clear @s minecraft:emerald 103
execute if score @s bt_emeralds matches 103 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 103 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 103 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 104 run clear @s minecraft:emerald 104
execute if score @s bt_emeralds matches 104 run clear @s minecraft:emerald_block 16
execute if score @s bt_emeralds matches 104 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 104 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 105 run clear @s minecraft:emerald 105
execute if score @s bt_emeralds matches 105 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 105 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 106 run clear @s minecraft:emerald 106
execute if score @s bt_emeralds matches 106 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 106 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 106 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 107 run clear @s minecraft:emerald 107
execute if score @s bt_emeralds matches 107 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 107 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 107 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 108 run clear @s minecraft:emerald 108
execute if score @s bt_emeralds matches 108 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 108 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 108 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 109 run clear @s minecraft:emerald 109
execute if score @s bt_emeralds matches 109 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 109 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 109 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 110 run clear @s minecraft:emerald 110
execute if score @s bt_emeralds matches 110 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 110 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 110 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 111 run clear @s minecraft:emerald 111
execute if score @s bt_emeralds matches 111 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 111 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 111 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 112 run clear @s minecraft:emerald 112
execute if score @s bt_emeralds matches 112 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 112 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 112 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 113 run clear @s minecraft:emerald 113
execute if score @s bt_emeralds matches 113 run clear @s minecraft:emerald_block 15
execute if score @s bt_emeralds matches 113 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 113 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 114 run clear @s minecraft:emerald 114
execute if score @s bt_emeralds matches 114 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 114 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 115 run clear @s minecraft:emerald 115
execute if score @s bt_emeralds matches 115 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 115 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 115 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 116 run clear @s minecraft:emerald 116
execute if score @s bt_emeralds matches 116 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 116 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 116 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 117 run clear @s minecraft:emerald 117
execute if score @s bt_emeralds matches 117 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 117 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 117 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 118 run clear @s minecraft:emerald 118
execute if score @s bt_emeralds matches 118 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 118 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 118 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 119 run clear @s minecraft:emerald 119
execute if score @s bt_emeralds matches 119 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 119 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 119 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 120 run clear @s minecraft:emerald 120
execute if score @s bt_emeralds matches 120 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 120 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 120 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 121 run clear @s minecraft:emerald 121
execute if score @s bt_emeralds matches 121 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 121 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 121 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 122 run clear @s minecraft:emerald 122
execute if score @s bt_emeralds matches 122 run clear @s minecraft:emerald_block 14
execute if score @s bt_emeralds matches 122 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 122 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 123 run clear @s minecraft:emerald 123
execute if score @s bt_emeralds matches 123 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 123 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 124 run clear @s minecraft:emerald 124
execute if score @s bt_emeralds matches 124 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 124 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 124 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 125 run clear @s minecraft:emerald 125
execute if score @s bt_emeralds matches 125 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 125 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 125 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 126 run clear @s minecraft:emerald 126
execute if score @s bt_emeralds matches 126 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 126 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 126 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 127 run clear @s minecraft:emerald 127
execute if score @s bt_emeralds matches 127 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 127 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 127 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 128 run clear @s minecraft:emerald 128
execute if score @s bt_emeralds matches 128 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 128 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 128 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 129 run clear @s minecraft:emerald 129
execute if score @s bt_emeralds matches 129 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 129 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 129 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 130 run clear @s minecraft:emerald 130
execute if score @s bt_emeralds matches 130 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 130 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 130 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 131 run clear @s minecraft:emerald 131
execute if score @s bt_emeralds matches 131 run clear @s minecraft:emerald_block 13
execute if score @s bt_emeralds matches 131 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 131 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 132 run clear @s minecraft:emerald 132
execute if score @s bt_emeralds matches 132 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 132 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 133 run clear @s minecraft:emerald 133
execute if score @s bt_emeralds matches 133 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 133 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 133 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 134 run clear @s minecraft:emerald 134
execute if score @s bt_emeralds matches 134 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 134 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 134 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 135 run clear @s minecraft:emerald 135
execute if score @s bt_emeralds matches 135 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 135 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 135 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 136 run clear @s minecraft:emerald 136
execute if score @s bt_emeralds matches 136 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 136 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 136 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 137 run clear @s minecraft:emerald 137
execute if score @s bt_emeralds matches 137 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 137 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 137 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 138 run clear @s minecraft:emerald 138
execute if score @s bt_emeralds matches 138 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 138 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 138 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 139 run clear @s minecraft:emerald 139
execute if score @s bt_emeralds matches 139 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 139 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 139 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 140 run clear @s minecraft:emerald 140
execute if score @s bt_emeralds matches 140 run clear @s minecraft:emerald_block 12
execute if score @s bt_emeralds matches 140 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 140 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 141 run clear @s minecraft:emerald 141
execute if score @s bt_emeralds matches 141 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 141 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 142 run clear @s minecraft:emerald 142
execute if score @s bt_emeralds matches 142 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 142 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 142 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 143 run clear @s minecraft:emerald 143
execute if score @s bt_emeralds matches 143 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 143 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 143 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 144 run clear @s minecraft:emerald 144
execute if score @s bt_emeralds matches 144 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 144 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 144 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 145 run clear @s minecraft:emerald 145
execute if score @s bt_emeralds matches 145 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 145 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 145 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 146 run clear @s minecraft:emerald 146
execute if score @s bt_emeralds matches 146 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 146 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 146 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 147 run clear @s minecraft:emerald 147
execute if score @s bt_emeralds matches 147 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 147 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 147 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 148 run clear @s minecraft:emerald 148
execute if score @s bt_emeralds matches 148 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 148 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 148 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 149 run clear @s minecraft:emerald 149
execute if score @s bt_emeralds matches 149 run clear @s minecraft:emerald_block 11
execute if score @s bt_emeralds matches 149 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 149 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 150 run clear @s minecraft:emerald 150
execute if score @s bt_emeralds matches 150 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 150 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 151 run clear @s minecraft:emerald 151
execute if score @s bt_emeralds matches 151 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 151 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 151 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 152 run clear @s minecraft:emerald 152
execute if score @s bt_emeralds matches 152 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 152 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 152 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 153 run clear @s minecraft:emerald 153
execute if score @s bt_emeralds matches 153 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 153 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 153 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 154 run clear @s minecraft:emerald 154
execute if score @s bt_emeralds matches 154 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 154 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 154 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 155 run clear @s minecraft:emerald 155
execute if score @s bt_emeralds matches 155 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 155 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 155 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 156 run clear @s minecraft:emerald 156
execute if score @s bt_emeralds matches 156 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 156 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 156 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 157 run clear @s minecraft:emerald 157
execute if score @s bt_emeralds matches 157 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 157 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 157 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 158 run clear @s minecraft:emerald 158
execute if score @s bt_emeralds matches 158 run clear @s minecraft:emerald_block 10
execute if score @s bt_emeralds matches 158 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 158 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 159 run clear @s minecraft:emerald 159
execute if score @s bt_emeralds matches 159 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 159 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 160 run clear @s minecraft:emerald 160
execute if score @s bt_emeralds matches 160 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 160 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 160 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 161 run clear @s minecraft:emerald 161
execute if score @s bt_emeralds matches 161 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 161 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 161 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 162 run clear @s minecraft:emerald 162
execute if score @s bt_emeralds matches 162 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 162 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 162 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 163 run clear @s minecraft:emerald 163
execute if score @s bt_emeralds matches 163 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 163 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 163 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 164 run clear @s minecraft:emerald 164
execute if score @s bt_emeralds matches 164 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 164 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 164 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 165 run clear @s minecraft:emerald 165
execute if score @s bt_emeralds matches 165 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 165 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 165 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 166 run clear @s minecraft:emerald 166
execute if score @s bt_emeralds matches 166 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 166 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 166 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 167 run clear @s minecraft:emerald 167
execute if score @s bt_emeralds matches 167 run clear @s minecraft:emerald_block 9
execute if score @s bt_emeralds matches 167 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 167 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 168 run clear @s minecraft:emerald 168
execute if score @s bt_emeralds matches 168 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 168 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 169 run clear @s minecraft:emerald 169
execute if score @s bt_emeralds matches 169 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 169 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 169 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 170 run clear @s minecraft:emerald 170
execute if score @s bt_emeralds matches 170 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 170 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 170 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 171 run clear @s minecraft:emerald 171
execute if score @s bt_emeralds matches 171 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 171 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 171 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 172 run clear @s minecraft:emerald 172
execute if score @s bt_emeralds matches 172 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 172 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 172 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 173 run clear @s minecraft:emerald 173
execute if score @s bt_emeralds matches 173 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 173 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 173 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 174 run clear @s minecraft:emerald 174
execute if score @s bt_emeralds matches 174 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 174 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 174 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 175 run clear @s minecraft:emerald 175
execute if score @s bt_emeralds matches 175 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 175 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 175 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 176 run clear @s minecraft:emerald 176
execute if score @s bt_emeralds matches 176 run clear @s minecraft:emerald_block 8
execute if score @s bt_emeralds matches 176 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 176 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 177 run clear @s minecraft:emerald 177
execute if score @s bt_emeralds matches 177 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 177 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 178 run clear @s minecraft:emerald 178
execute if score @s bt_emeralds matches 178 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 178 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 178 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 179 run clear @s minecraft:emerald 179
execute if score @s bt_emeralds matches 179 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 179 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 179 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 180 run clear @s minecraft:emerald 180
execute if score @s bt_emeralds matches 180 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 180 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 180 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 181 run clear @s minecraft:emerald 181
execute if score @s bt_emeralds matches 181 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 181 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 181 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 182 run clear @s minecraft:emerald 182
execute if score @s bt_emeralds matches 182 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 182 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 182 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 183 run clear @s minecraft:emerald 183
execute if score @s bt_emeralds matches 183 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 183 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 183 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 184 run clear @s minecraft:emerald 184
execute if score @s bt_emeralds matches 184 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 184 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 184 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 185 run clear @s minecraft:emerald 185
execute if score @s bt_emeralds matches 185 run clear @s minecraft:emerald_block 7
execute if score @s bt_emeralds matches 185 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 185 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 186 run clear @s minecraft:emerald 186
execute if score @s bt_emeralds matches 186 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 186 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 187 run clear @s minecraft:emerald 187
execute if score @s bt_emeralds matches 187 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 187 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 187 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 188 run clear @s minecraft:emerald 188
execute if score @s bt_emeralds matches 188 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 188 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 188 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 189 run clear @s minecraft:emerald 189
execute if score @s bt_emeralds matches 189 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 189 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 189 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 190 run clear @s minecraft:emerald 190
execute if score @s bt_emeralds matches 190 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 190 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 190 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 191 run clear @s minecraft:emerald 191
execute if score @s bt_emeralds matches 191 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 191 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 191 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 192 run clear @s minecraft:emerald 192
execute if score @s bt_emeralds matches 192 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 192 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 192 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 193 run clear @s minecraft:emerald 193
execute if score @s bt_emeralds matches 193 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 193 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 193 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 194 run clear @s minecraft:emerald 194
execute if score @s bt_emeralds matches 194 run clear @s minecraft:emerald_block 6
execute if score @s bt_emeralds matches 194 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 194 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 195 run clear @s minecraft:emerald 195
execute if score @s bt_emeralds matches 195 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 195 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 196 run clear @s minecraft:emerald 196
execute if score @s bt_emeralds matches 196 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 196 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 196 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 197 run clear @s minecraft:emerald 197
execute if score @s bt_emeralds matches 197 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 197 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 197 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 198 run clear @s minecraft:emerald 198
execute if score @s bt_emeralds matches 198 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 198 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 198 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 199 run clear @s minecraft:emerald 199
execute if score @s bt_emeralds matches 199 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 199 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 199 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 200 run clear @s minecraft:emerald 200
execute if score @s bt_emeralds matches 200 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 200 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 200 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 201 run clear @s minecraft:emerald 201
execute if score @s bt_emeralds matches 201 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 201 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 201 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 202 run clear @s minecraft:emerald 202
execute if score @s bt_emeralds matches 202 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 202 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 202 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 203 run clear @s minecraft:emerald 203
execute if score @s bt_emeralds matches 203 run clear @s minecraft:emerald_block 5
execute if score @s bt_emeralds matches 203 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 203 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 204 run clear @s minecraft:emerald 204
execute if score @s bt_emeralds matches 204 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 204 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 205 run clear @s minecraft:emerald 205
execute if score @s bt_emeralds matches 205 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 205 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 205 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 206 run clear @s minecraft:emerald 206
execute if score @s bt_emeralds matches 206 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 206 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 206 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 207 run clear @s minecraft:emerald 207
execute if score @s bt_emeralds matches 207 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 207 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 207 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 208 run clear @s minecraft:emerald 208
execute if score @s bt_emeralds matches 208 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 208 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 208 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 209 run clear @s minecraft:emerald 209
execute if score @s bt_emeralds matches 209 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 209 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 209 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 210 run clear @s minecraft:emerald 210
execute if score @s bt_emeralds matches 210 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 210 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 210 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 211 run clear @s minecraft:emerald 211
execute if score @s bt_emeralds matches 211 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 211 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 211 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 212 run clear @s minecraft:emerald 212
execute if score @s bt_emeralds matches 212 run clear @s minecraft:emerald_block 4
execute if score @s bt_emeralds matches 212 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 212 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 213 run clear @s minecraft:emerald 213
execute if score @s bt_emeralds matches 213 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 213 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 214 run clear @s minecraft:emerald 214
execute if score @s bt_emeralds matches 214 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 214 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 214 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 215 run clear @s minecraft:emerald 215
execute if score @s bt_emeralds matches 215 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 215 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 215 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 216 run clear @s minecraft:emerald 216
execute if score @s bt_emeralds matches 216 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 216 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 216 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 217 run clear @s minecraft:emerald 217
execute if score @s bt_emeralds matches 217 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 217 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 217 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 218 run clear @s minecraft:emerald 218
execute if score @s bt_emeralds matches 218 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 218 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 218 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 219 run clear @s minecraft:emerald 219
execute if score @s bt_emeralds matches 219 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 219 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 219 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 220 run clear @s minecraft:emerald 220
execute if score @s bt_emeralds matches 220 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 220 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 220 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 221 run clear @s minecraft:emerald 221
execute if score @s bt_emeralds matches 221 run clear @s minecraft:emerald_block 3
execute if score @s bt_emeralds matches 221 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 221 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 222 run clear @s minecraft:emerald 222
execute if score @s bt_emeralds matches 222 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 222 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 223 run clear @s minecraft:emerald 223
execute if score @s bt_emeralds matches 223 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 223 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 223 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 224 run clear @s minecraft:emerald 224
execute if score @s bt_emeralds matches 224 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 224 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 224 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 225 run clear @s minecraft:emerald 225
execute if score @s bt_emeralds matches 225 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 225 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 225 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 226 run clear @s minecraft:emerald 226
execute if score @s bt_emeralds matches 226 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 226 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 226 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 227 run clear @s minecraft:emerald 227
execute if score @s bt_emeralds matches 227 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 227 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 227 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 228 run clear @s minecraft:emerald 228
execute if score @s bt_emeralds matches 228 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 228 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 228 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 229 run clear @s minecraft:emerald 229
execute if score @s bt_emeralds matches 229 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 229 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 229 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 230 run clear @s minecraft:emerald 230
execute if score @s bt_emeralds matches 230 run clear @s minecraft:emerald_block 2
execute if score @s bt_emeralds matches 230 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 230 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 231 run clear @s minecraft:emerald 231
execute if score @s bt_emeralds matches 231 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 231 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 232 run clear @s minecraft:emerald 232
execute if score @s bt_emeralds matches 232 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 232 run give @s minecraft:emerald 1
execute if score @s bt_emeralds matches 232 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 233 run clear @s minecraft:emerald 233
execute if score @s bt_emeralds matches 233 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 233 run give @s minecraft:emerald 2
execute if score @s bt_emeralds matches 233 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 234 run clear @s minecraft:emerald 234
execute if score @s bt_emeralds matches 234 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 234 run give @s minecraft:emerald 3
execute if score @s bt_emeralds matches 234 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 235 run clear @s minecraft:emerald 235
execute if score @s bt_emeralds matches 235 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 235 run give @s minecraft:emerald 4
execute if score @s bt_emeralds matches 235 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 236 run clear @s minecraft:emerald 236
execute if score @s bt_emeralds matches 236 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 236 run give @s minecraft:emerald 5
execute if score @s bt_emeralds matches 236 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 237 run clear @s minecraft:emerald 237
execute if score @s bt_emeralds matches 237 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 237 run give @s minecraft:emerald 6
execute if score @s bt_emeralds matches 237 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 238 run clear @s minecraft:emerald 238
execute if score @s bt_emeralds matches 238 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 238 run give @s minecraft:emerald 7
execute if score @s bt_emeralds matches 238 run function builder_tables:dynamic/build_cl0_7
execute if score @s bt_emeralds matches 239 run clear @s minecraft:emerald 239
execute if score @s bt_emeralds matches 239 run clear @s minecraft:emerald_block 1
execute if score @s bt_emeralds matches 239 run give @s minecraft:emerald 8
execute if score @s bt_emeralds matches 239 run function builder_tables:dynamic/build_cl0_7
