# Precio: 100 bloques = 10 esmeraldas (1000 = 100). Precio entero redondeado hacia arriba.
scoreboard players set @s bt_price 176
execute store result score @s bt_emeralds run clear @s minecraft:emerald 0
execute store result score @s bt_emerald_blocks run clear @s minecraft:emerald_block 0
scoreboard players operation @s bt_balance = @s bt_emeralds
scoreboard players operation @s bt_remaining = @s bt_emerald_blocks
scoreboard players operation @s bt_remaining *= #nine bt_price
scoreboard players operation @s bt_balance += @s bt_remaining
execute if score @s bt_balance matches ..175 run tellraw @s {text:'❌ No tienes suficientes esmeraldas. Precio: 176 esmeraldas.',color:'red'}
execute if score @s bt_balance matches 176.. run function builder_tables:dynamic/charge_clx_2
