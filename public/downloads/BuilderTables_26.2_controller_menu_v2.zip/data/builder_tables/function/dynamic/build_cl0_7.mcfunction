
kill @e[tag=bt_anchor_cl0_7]
execute unless score @s bt_rot_state matches 0.. run scoreboard players set @s bt_rot_state 0
execute if score @s bt_rot_state matches 0 at @s run summon minecraft:marker ~ ~ ~ {Tags:["bt_anchor","bt_anchor_cl0_7","bt_rot0"]}
execute if score @s bt_rot_state matches 1 at @s run summon minecraft:marker ~ ~ ~ {Tags:["bt_anchor","bt_anchor_cl0_7","bt_rot1"]}
execute if score @s bt_rot_state matches 2 at @s run summon minecraft:marker ~ ~ ~ {Tags:["bt_anchor","bt_anchor_cl0_7","bt_rot2"]}
execute if score @s bt_rot_state matches 3 at @s run summon minecraft:marker ~ ~ ~ {Tags:["bt_anchor","bt_anchor_cl0_7","bt_rot3"]}
execute if score @s bt_rot_state matches 0 at @s run place template builder_tables:cl0_7 ~ ~ ~ none
execute if score @s bt_rot_state matches 1 at @s run place template builder_tables:cl0_7 ~ ~ ~ clockwise_90
execute if score @s bt_rot_state matches 2 at @s run place template builder_tables:cl0_7 ~ ~ ~ 180
execute if score @s bt_rot_state matches 3 at @s run place template builder_tables:cl0_7 ~ ~ ~ counterclockwise_90
execute at @s run particle minecraft:cloud ~ ~1 ~ 1 1 1 0.1 100
execute at @s run playsound minecraft:block.anvil.use player @a ~ ~ ~
tellraw @s {"text":"✔ Estructura 'cl0_7' construida con éxito.","color":"green"}
