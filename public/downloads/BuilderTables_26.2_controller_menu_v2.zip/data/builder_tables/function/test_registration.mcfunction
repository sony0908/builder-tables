tellraw @s {text:"[Builder Tables] Funciones registradas correctamente.",color:"green"}
