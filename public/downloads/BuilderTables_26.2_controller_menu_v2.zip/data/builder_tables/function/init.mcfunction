scoreboard objectives remove bt_trigger
scoreboard objectives remove bt_undo
scoreboard objectives remove bt_rot
scoreboard objectives remove bt_book
scoreboard objectives remove bt_active
scoreboard objectives remove bt_select
scoreboard objectives remove bt_exit
scoreboard objectives remove bt_controller_map_used
scoreboard objectives remove bt_controller_filled_map_used
scoreboard objectives remove bt_rot_state
scoreboard objectives remove bt_price
scoreboard objectives remove bt_emeralds
scoreboard objectives remove bt_emerald_blocks
scoreboard objectives remove bt_balance
scoreboard objectives remove bt_remaining
scoreboard objectives remove bt_blocks_to_pay
scoreboard objectives remove bt_change
scoreboard objectives add bt_trigger trigger
scoreboard objectives add bt_undo trigger
scoreboard objectives add bt_rot trigger
scoreboard objectives add bt_book trigger
scoreboard objectives add bt_active dummy
scoreboard objectives add bt_select trigger
scoreboard objectives add bt_exit trigger
scoreboard objectives add bt_controller_map_used minecraft.used:minecraft.map
scoreboard objectives add bt_controller_filled_map_used minecraft.used:minecraft.filled_map
scoreboard objectives add bt_rot_state dummy
scoreboard objectives add bt_price dummy
scoreboard objectives add bt_emeralds dummy
scoreboard objectives add bt_emerald_blocks dummy
scoreboard objectives add bt_balance dummy
scoreboard objectives add bt_remaining dummy
scoreboard objectives add bt_blocks_to_pay dummy
scoreboard objectives add bt_change dummy
scoreboard players set #nine bt_price 9
tellraw @a {text:'[Builder Tables] Datapack 26.2 cargado correctamente.',color:'green'}
execute as @a run scoreboard players set @s bt_rot_state 0
execute as @a run scoreboard players set @s bt_active 0