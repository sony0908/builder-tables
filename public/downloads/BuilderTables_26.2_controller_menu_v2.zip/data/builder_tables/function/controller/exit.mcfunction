# Salir no abre ningún otro diálogo ni libro.
scoreboard players set @s bt_active 0
scoreboard players set @s bt_rot_state 0