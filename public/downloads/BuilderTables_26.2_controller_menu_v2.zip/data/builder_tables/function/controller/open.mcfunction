# Una única fuente de verdad: bt_active decide qué diálogo se abre.
execute if score @s bt_active matches 0 run dialog show @s builder_tables:catalogo
execute if score @s bt_active matches 1 run dialog show @s builder_tables:plan_cl0_1
execute if score @s bt_active matches 2 run dialog show @s builder_tables:plan_cl0_7
execute if score @s bt_active matches 3 run dialog show @s builder_tables:plan_clx_2