# Botones del Catalogo de Planos
execute as @a[scores={bt_trigger=1}] run function builder_tables:dynamic/pay_cl0_1
execute as @a[scores={bt_undo=1}] run function builder_tables:dynamic/undo_cl0_1
execute as @a[scores={bt_trigger=2}] run function builder_tables:dynamic/pay_cl0_7
execute as @a[scores={bt_undo=2}] run function builder_tables:dynamic/undo_cl0_7
execute as @a[scores={bt_trigger=3}] run function builder_tables:dynamic/pay_clx_2
execute as @a[scores={bt_undo=3}] run function builder_tables:dynamic/undo_clx_2

scoreboard players reset @a[scores={bt_trigger=1..}] bt_trigger
scoreboard players reset @a[scores={bt_undo=1..}] bt_undo
