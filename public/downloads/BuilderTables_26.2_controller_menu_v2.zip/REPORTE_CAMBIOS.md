# Builder Tables 26.2 — reporte de cambios

Base: `BuilderTables_26.2_emerald_pricing_v2.zip`.

## Arquitectura

- `minecraft:map` con `custom_data={builder_tables_controller:1b}` es el único controlador del menú.
- `bt_active` es la única fuente de verdad: 0 catálogo, 1 cl0_1, 2 cl0_7, 3 clx_2.
- El catálogo solamente establece `bt_active` mediante `bt_select` y cierra su diálogo.
- El siguiente uso del controlador abre el menú correspondiente.
- El botón Salir ejecuta `bt_exit`, limpia `bt_active` y la rotación temporal; no abre otro diálogo ni libro.
- `bt_book` queda reservado exclusivamente para entregar los libros de materiales.

## Cambios localizados

- Añadidos: `function/give_controller.mcfunction`, `function/controller/open.mcfunction` y `function/controller/exit.mcfunction`.
- Actualizados: `init.mcfunction`, `tick.mcfunction`, los cuatro diálogos y el alias de compatibilidad `give_book.mcfunction`.
- Retirados de esta copia: la receta y el avance del antiguo libro-catálogo.
- Conservados sin modificación: estructuras NBT, cobro, precios, construcción y rotación.
- Corregido UNDO: respeta los cuatro sentidos de rotación y devuelve el precio del plano eliminado.

## Validación realizada

- JSON: analizado correctamente.
- `pack.mcmeta`: conservado con formatos mínimo y máximo `[107, 1]`.
- Referencias de funciones y diálogos: comprobadas estáticamente.
- Sin referencias activas a `ABRIR CATÁLOGO`, `ABRIR MENÚ` ni `give_active_book`.
- Los libros de receta siguen usando `written_book_content` con páginas de componentes SNBT directos; no contienen el menú.
- ZIP: se abre y se recorre completamente tras generarse.

No se ejecutó Minecraft 26.2 desde este entorno: el flujo fue revisado de forma estática y lógica, no mediante una prueba dentro del juego.

## Uso

`/function builder_tables:give_controller`