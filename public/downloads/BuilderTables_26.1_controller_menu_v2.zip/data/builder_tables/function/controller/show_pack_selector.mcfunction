tellraw @s ["",{"text":"═══════════════════════════════════════","color":"gold","strikethrough":true}]
tellraw @s ["",{"text":" 📦 PAQUETES DE CONSTRUCCIÓN DISPONIBLES","color":"gold","bold":true}]
tellraw @s ["",{"text":" Selecciona un paquete para abrir sus planos:","color":"gray"}]
function #builder_tables:menu/show_pack_entry
tellraw @s ["",{"text":"═══════════════════════════════════════","color":"gold","strikethrough":true}]
