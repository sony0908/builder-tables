# Abrir catálogo único o selector de paquetes
scoreboard players set #installed_packs bt_pack_count 0
function #builder_tables:menu/register_pack
execute if score #installed_packs bt_pack_count matches 1 run function #builder_tables:menu/open_single_pack
execute if score #installed_packs bt_pack_count matches 2.. run function builder_tables:controller/show_pack_selector
execute if score #installed_packs bt_pack_count matches ..0 run dialog show @s builder_tables:catalogo
