# Abrir catalogo base al recibir el trigger 1
execute as @a[scores={bt_open_pack=1}] run dialog show @s builder_tables:catalogo
