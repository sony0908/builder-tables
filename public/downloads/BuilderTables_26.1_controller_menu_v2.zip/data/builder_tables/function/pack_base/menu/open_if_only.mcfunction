# Si es el único paquete instalado, abrir catálogo base directamente
execute if score #installed_packs bt_pack_count matches 1 run dialog show @s builder_tables:catalogo
