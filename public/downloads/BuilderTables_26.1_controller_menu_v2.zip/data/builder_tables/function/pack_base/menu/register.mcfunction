# Registrar presencia del paquete base
scoreboard players add #installed_packs bt_pack_count 1
