execute as @a unless score @s bt_rot_state matches 0.. run scoreboard players set @s bt_rot_state 0
scoreboard players enable @a bt_trigger
scoreboard players enable @a bt_undo
scoreboard players enable @a bt_rot
scoreboard players enable @a bt_book
scoreboard players enable @a bt_select
scoreboard players enable @a bt_exit

# El mapa controlador se valida por custom_data; los mapas normales nunca abren el menú.
execute as @a[scores={bt_controller_map_used=1..}] if items entity @s weapon.mainhand minecraft:map[custom_data~{builder_tables_controller:1b}] run function builder_tables:controller/open
execute as @a[scores={bt_controller_map_used=1..}] if items entity @s weapon.mainhand minecraft:filled_map[custom_data~{builder_tables_controller:1b}] run function builder_tables:controller/open
execute as @a[scores={bt_controller_filled_map_used=1..}] if items entity @s weapon.mainhand minecraft:map[custom_data~{builder_tables_controller:1b}] run function builder_tables:controller/open
execute as @a[scores={bt_controller_filled_map_used=1..}] if items entity @s weapon.mainhand minecraft:filled_map[custom_data~{builder_tables_controller:1b}] run function builder_tables:controller/open
scoreboard players reset @a[scores={bt_controller_map_used=1..}] bt_controller_map_used
scoreboard players reset @a[scores={bt_controller_filled_map_used=1..}] bt_controller_filled_map_used

execute as @a[scores={bt_select=1}] run scoreboard players set @s bt_active 1
execute as @a[scores={bt_select=2}] run scoreboard players set @s bt_active 2
execute as @a[scores={bt_select=3}] run scoreboard players set @s bt_active 3
scoreboard players reset @a[scores={bt_select=1..}] bt_select

execute as @a[scores={bt_exit=1..}] run function builder_tables:controller/exit
scoreboard players reset @a[scores={bt_exit=1..}] bt_exit

execute as @a[scores={bt_book=1}] run function builder_tables:give_recipe
scoreboard players reset @a[scores={bt_book=1..}] bt_book
function builder_tables:dynamic_triggers
function builder_tables:rotar
# Disparadores bancarios
scoreboard players enable @a bt_deposit
scoreboard players enable @a bt_withdraw
scoreboard players enable @a bt_balance
scoreboard players enable @a bt_bank_menu
execute as @a[advancements={builder_tables_generated:used_bank_card=true}] run function builder_tables_generated:bank/open
execute as @a[scores={bt_deposit=1}] run function builder_tables_generated:bank/deposit_64_emeralds
execute as @a[scores={bt_deposit=2}] run function builder_tables_generated:bank/deposit_64_blocks
execute as @a[scores={bt_deposit=3}] run function builder_tables_generated:bank/deposit_all
scoreboard players reset @a[scores={bt_deposit=1..}] bt_deposit
execute as @a[scores={bt_withdraw=1}] run function builder_tables_generated:bank/withdraw_64_emeralds
execute as @a[scores={bt_withdraw=2}] run function builder_tables_generated:bank/withdraw_64_blocks
scoreboard players reset @a[scores={bt_withdraw=1..}] bt_withdraw
execute as @a[scores={bt_balance=1..}] run function builder_tables_generated:bank/balance
scoreboard players reset @a[scores={bt_balance=1..}] bt_balance
execute as @a[scores={bt_bank_menu=1..}] run function builder_tables_generated:bank/open
scoreboard players reset @a[scores={bt_bank_menu=1..}] bt_bank_menu
