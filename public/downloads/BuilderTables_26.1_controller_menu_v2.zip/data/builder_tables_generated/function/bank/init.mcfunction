scoreboard objectives add bt_bank dummy
scoreboard objectives add bt_deposit trigger
scoreboard objectives add bt_withdraw trigger
scoreboard objectives add bt_balance trigger
scoreboard objectives add bt_bank_menu trigger
scoreboard objectives add bt_has_card dummy
scoreboard objectives add bt_temp dummy
scoreboard objectives add bt_temp_emeralds dummy
scoreboard objectives add bt_temp_blocks dummy
scoreboard objectives add bt_bank_timer dummy
scoreboard objectives add bt_interest dummy
scoreboard objectives add bt_interest_math dummy
scoreboard players set #hundred bt_interest_math 100
scoreboard players set #cap bt_interest_math 250
scoreboard players set #nine bt_price 9
recipe give @a builder_tables:bank_card
advancement revoke @a only builder_tables_generated:used_bank_card
