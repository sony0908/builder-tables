tellraw @s [{"text":"[Banco] Saldo actual: ","color":"gold"},{"score":{"name":"@s","objective":"bt_bank"},"color":"green"},{"text":" esmeraldas.","color":"gold"}]
title @s actionbar [{"text":"Saldo Tarjeta: ","color":"gold"},{"score":{"name":"@s","objective":"bt_bank"},"color":"green"},{"text":" esmeraldas","color":"gold"}]
