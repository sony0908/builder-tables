execute as @a run function builder_tables_generated:bank/player_interest
