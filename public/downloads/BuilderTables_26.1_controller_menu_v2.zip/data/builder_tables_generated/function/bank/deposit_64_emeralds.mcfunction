execute store result score @s bt_temp run clear @s minecraft:emerald 0
execute if score @s bt_temp matches 64.. run clear @s minecraft:emerald 64
execute if score @s bt_temp matches 64.. run scoreboard players add @s bt_bank 64
execute if score @s bt_temp matches 64.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.2
execute if score @s bt_temp matches 64.. run tellraw @s [{"text":"[Banco] +64 esmeraldas depositadas. Nuevo saldo: ","color":"green"},{"score":{"name":"@s","objective":"bt_bank"},"color":"gold"}]
execute unless score @s bt_temp matches 64.. run tellraw @s {"text":"[Banco] No tienes 64 esmeraldas sueltas en tu inventario.","color":"red"}
