execute if score @s bt_bank matches 64.. run scoreboard players remove @s bt_bank 64
execute if score @s bt_bank matches 64.. run give @s minecraft:emerald 64
execute if score @s bt_bank matches 64.. run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 1 1
execute if score @s bt_bank matches 64.. run tellraw @s [{"text":"[Banco] Has retirado 64 esmeraldas. Saldo restante: ","color":"yellow"},{"score":{"name":"@s","objective":"bt_bank"},"color":"gold"}]
execute unless score @s bt_bank matches 64.. run tellraw @s {"text":"[Banco] Saldo insuficiente para retirar 64 esmeraldas.","color":"red"}
