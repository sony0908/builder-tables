scoreboard players set #nine bt_price 9
execute store result score @s bt_temp_emeralds run clear @s minecraft:emerald
execute store result score @s bt_temp_blocks run clear @s minecraft:emerald_block
scoreboard players operation @s bt_temp_blocks *= #nine bt_price
scoreboard players operation @s bt_temp_emeralds += @s bt_temp_blocks
execute if score @s bt_temp_emeralds matches 1.. run scoreboard players operation @s bt_bank += @s bt_temp_emeralds
execute if score @s bt_temp_emeralds matches 1.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.2
execute if score @s bt_temp_emeralds matches 1.. run tellraw @s [{"text":"[Banco] Se han depositado ","color":"green"},{"score":{"name":"@s","objective":"bt_temp_emeralds"},"color":"gold"},{"text":" esmeraldas en total. Saldo actual: ","color":"green"},{"score":{"name":"@s","objective":"bt_bank"},"color":"gold"}]
execute unless score @s bt_temp_emeralds matches 1.. run tellraw @s {"text":"[Banco] No tienes esmeraldas ni bloques en el inventario.","color":"red"}
