scoreboard players enable @a bt_deposit
scoreboard players enable @a bt_withdraw
scoreboard players enable @a bt_balance
scoreboard players enable @a bt_bank_menu
# Fail-safe: Si el avance used_bank_card fue otorgado, abrir menu y revocar
execute as @a[advancements={builder_tables_generated:used_bank_card=true}] run function builder_tables_generated:bank/open
execute as @a[scores={bt_deposit=1}] run function builder_tables_generated:bank/deposit_64_emeralds
execute as @a[scores={bt_deposit=2}] run function builder_tables_generated:bank/deposit_64_blocks
execute as @a[scores={bt_deposit=3}] run function builder_tables_generated:bank/deposit_all
scoreboard players reset @a[scores={bt_deposit=1..}] bt_deposit
execute as @a[scores={bt_withdraw=1}] run function builder_tables_generated:bank/withdraw_64_emeralds
execute as @a[scores={bt_withdraw=2}] run function builder_tables_generated:bank/withdraw_64_blocks
scoreboard players reset @a[scores={bt_withdraw=1..}] bt_withdraw
execute as @a[scores={bt_balance=1..}] run function builder_tables_generated:bank/balance
scoreboard players reset @a[scores={bt_balance=1..}] bt_balance
execute as @a[scores={bt_bank_menu=1..}] run function builder_tables_generated:bank/open
scoreboard players reset @a[scores={bt_bank_menu=1..}] bt_bank_menu
# Ciclo diario de intereses bancarios (24000 ticks = 1 dia de Minecraft)
scoreboard players add #timer bt_bank_timer 1
execute if score #timer bt_bank_timer matches 24000.. run function builder_tables_generated:bank/apply_interest
execute if score #timer bt_bank_timer matches 24000.. run scoreboard players set #timer bt_bank_timer 0
