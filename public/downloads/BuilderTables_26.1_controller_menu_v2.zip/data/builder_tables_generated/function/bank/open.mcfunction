advancement revoke @s only builder_tables_generated:used_bank_card
function builder_tables_generated:bank/balance
dialog show @s builder_tables:bank_menu
