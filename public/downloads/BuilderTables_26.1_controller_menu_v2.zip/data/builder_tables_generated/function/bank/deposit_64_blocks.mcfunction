execute store result score @s bt_temp run clear @s minecraft:emerald_block 0
execute if score @s bt_temp matches 64.. run clear @s minecraft:emerald_block 64
execute if score @s bt_temp matches 64.. run scoreboard players add @s bt_bank 576
execute if score @s bt_temp matches 64.. run playsound minecraft:entity.experience_orb.pickup player @s ~ ~ ~ 1 1.2
execute if score @s bt_temp matches 64.. run tellraw @s [{"text":"[Banco] +64 bloques depositados (+576 esmeraldas). Nuevo saldo: ","color":"green"},{"score":{"name":"@s","objective":"bt_bank"},"color":"gold"}]
execute unless score @s bt_temp matches 64.. run tellraw @s {"text":"[Banco] No tienes 64 bloques de esmeralda en tu inventario.","color":"red"}
