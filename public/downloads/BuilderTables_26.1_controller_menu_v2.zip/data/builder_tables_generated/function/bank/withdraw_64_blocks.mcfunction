execute if score @s bt_bank matches 576.. run scoreboard players remove @s bt_bank 576
execute if score @s bt_bank matches 576.. run give @s minecraft:emerald_block 64
execute if score @s bt_bank matches 576.. run playsound minecraft:entity.item.pickup player @s ~ ~ ~ 1 1
execute if score @s bt_bank matches 576.. run tellraw @s [{"text":"[Banco] Has retirado 64 bloques de esmeralda. Saldo restante: ","color":"yellow"},{"score":{"name":"@s","objective":"bt_bank"},"color":"gold"}]
execute unless score @s bt_bank matches 576.. run tellraw @s {"text":"[Banco] Saldo insuficiente para retirar 64 bloques (requiere 576 esmeraldas).","color":"red"}
