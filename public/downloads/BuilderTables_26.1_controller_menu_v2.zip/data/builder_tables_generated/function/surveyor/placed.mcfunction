# Eliminar anclajes previos en esta ubicación exacta si existieran
kill @e[type=minecraft:marker,tag=bt_surveyor_anchor,distance=..0.5]
summon minecraft:marker ~ ~ ~ {Tags:["bt_surveyor_anchor"]}
playsound minecraft:block.note_block.chime player @a ~ ~ ~ 1 1.5
tellraw @s [{"text":"[Topografía] ","color":"aqua","bold":true},{"text":"Bloque de Topografía y Obras colocado. Haz clic derecho en él para abrir el Centro de Control.","color":"gold"}]
