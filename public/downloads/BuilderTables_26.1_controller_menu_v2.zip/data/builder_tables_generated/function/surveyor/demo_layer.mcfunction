$execute store result score #layer_blocks bt_temp run fill $(x1) $(cur_y) $(z1) $(x2) $(cur_y) $(z2) air
scoreboard players operation #total_blocks bt_temp += #layer_blocks bt_temp
scoreboard players add #cur_y bt_temp 1
execute store result storage builder_tables:surveyor cur_y int 1 run scoreboard players get #cur_y bt_temp
execute if score #cur_y bt_temp <= #max_y bt_temp run function builder_tables_generated:surveyor/demo_layer with storage builder_tables:surveyor
