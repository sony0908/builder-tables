execute at @s run function builder_tables_generated:surveyor/ray_corner_2
scoreboard players set @s bt_surv_step 0
playsound minecraft:block.anvil.land player @s ~ ~ ~ 0.8 1.4
tellraw @s [{"text":"[Topografía] ","color":"aqua","bold":true},{"text":"Segundo punto seleccionado en ","color":"gold","bold":true},{"text":"[","color":"yellow"},{"score":{"name":"#x2","objective":"bt_temp"},"color":"gold","bold":true},{"text":", ","color":"yellow"},{"score":{"name":"#y2","objective":"bt_temp"},"color":"gold","bold":true},{"text":", ","color":"yellow"},{"score":{"name":"#z2","objective":"bt_temp"},"color":"gold","bold":true},{"text":"]","color":"yellow"}]
