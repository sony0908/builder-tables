scoreboard players enable @a bt_surv_copy
scoreboard players enable @a bt_surv_demo_ask
scoreboard players enable @a bt_surv_demo_exec
scoreboard players enable @a bt_surv_clear
scoreboard players enable @a bt_give_tape
scoreboard players enable @a bt_surv_rm_sb
# Entrega de cinta solicitada
execute as @a[scores={bt_give_tape=1..}] at @s run function builder_tables:give_tape
scoreboard players reset @a[scores={bt_give_tape=1..}] bt_give_tape
# Clic derecho con la cinta de topógrafo (carrot_on_a_stick)
execute as @a[scores={bt_tape_used=1..}] at @s if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[custom_data~{builder_tables_surveyor_tape:1b}] run function builder_tables_generated:surveyor/use_tape
execute as @a[scores={bt_tape_used=1..}] at @s if items entity @s weapon.offhand minecraft:carrot_on_a_stick[custom_data~{builder_tables_surveyor_tape:1b}] run function builder_tables_generated:surveyor/use_tape
scoreboard players reset @a[scores={bt_tape_used=1..}] bt_tape_used
# Petición de copia a NBT
execute as @a[scores={bt_surv_copy=1..}] at @s run function builder_tables_generated:surveyor/copy_nbt
scoreboard players reset @a[scores={bt_surv_copy=1..}] bt_surv_copy
# Petición de diálogo de confirmación de demolición
execute as @a[scores={bt_surv_demo_ask=1..}] at @s run function builder_tables_generated:surveyor/open_demo_confirm
scoreboard players reset @a[scores={bt_surv_demo_ask=1..}] bt_surv_demo_ask
# Ejecución definitiva de demolición y venta
execute as @a[scores={bt_surv_demo_exec=1..}] at @s run function builder_tables_generated:surveyor/execute_demo
scoreboard players reset @a[scores={bt_surv_demo_exec=1..}] bt_surv_demo_exec
# Limpiar esquinas
execute as @a[scores={bt_surv_clear=1..}] at @s run function builder_tables_generated:surveyor/clear_selection
scoreboard players reset @a[scores={bt_surv_clear=1..}] bt_surv_clear
# Retirar bloque de estructura
execute as @a[scores={bt_surv_rm_sb=1..}] at @s run function builder_tables_generated:surveyor/remove_structure_block
scoreboard players reset @a[scores={bt_surv_rm_sb=1..}] bt_surv_rm_sb
# Efectos visuales continuos de partículas en las esquinas marcadas
execute as @e[type=minecraft:marker,tag=bt_surv_c1] at @s run particle minecraft:happy_villager ~0.5 ~1.1 ~0.5 0.1 0.1 0.1 0 2
execute as @e[type=minecraft:marker,tag=bt_surv_c2] at @s run particle minecraft:wax_on ~0.5 ~1.1 ~0.5 0.1 0.1 0.1 0 2
