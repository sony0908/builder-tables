kill @e[type=minecraft:marker,tag=bt_surv_sb]
$setblock $(sb_x) $(sb_y) $(sb_z) minecraft:structure_block[mode=save]{mode:"SAVE",name:"mi_construccion",sizeX:$(size_x),sizeY:$(size_y),sizeZ:$(size_z),posX:$(pos_x),posY:$(pos_y),posZ:$(pos_z),showboundingbox:1b} replace
$summon minecraft:marker $(sb_x) $(sb_y) $(sb_z) {Tags:["bt_surv_sb"]}
$particle minecraft:totem_of_undying $(sb_x) $(sb_y) $(sb_z) 1 1 1 0.1 30
