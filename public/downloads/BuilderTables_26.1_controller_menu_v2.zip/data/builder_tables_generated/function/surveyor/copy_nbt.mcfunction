execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run tellraw @s {"text":"[Topografía] Falta marcar el primer punto con la Cinta de Topógrafo.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run return 0
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run tellraw @s {"text":"[Topografía] Falta marcar el segundo punto con la Cinta de Topógrafo.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run return 0
# 1. Obtener coordenadas de ambas esquinas más cercanas al jugador
execute store result score #x1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,sort=nearest,limit=1] Pos[0]
execute store result score #y1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,sort=nearest,limit=1] Pos[1]
execute store result score #z1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,sort=nearest,limit=1] Pos[2]
execute store result score #x2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,sort=nearest,limit=1] Pos[0]
execute store result score #y2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,sort=nearest,limit=1] Pos[1]
execute store result score #z2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,sort=nearest,limit=1] Pos[2]
# 2. Calcular límites mínimos y máximos en cada eje
scoreboard players operation #min_x bt_temp = #x1 bt_temp
scoreboard players operation #max_x bt_temp = #x2 bt_temp
execute if score #x1 bt_temp > #x2 bt_temp run scoreboard players operation #min_x bt_temp = #x2 bt_temp
execute if score #x1 bt_temp > #x2 bt_temp run scoreboard players operation #max_x bt_temp = #x1 bt_temp
scoreboard players operation #min_y bt_temp = #y1 bt_temp
scoreboard players operation #max_y bt_temp = #y2 bt_temp
execute if score #y1 bt_temp > #y2 bt_temp run scoreboard players operation #min_y bt_temp = #y2 bt_temp
execute if score #y1 bt_temp > #y2 bt_temp run scoreboard players operation #max_y bt_temp = #y1 bt_temp
scoreboard players operation #min_z bt_temp = #z1 bt_temp
scoreboard players operation #max_z bt_temp = #z2 bt_temp
execute if score #z1 bt_temp > #z2 bt_temp run scoreboard players operation #min_z bt_temp = #z2 bt_temp
execute if score #z1 bt_temp > #z2 bt_temp run scoreboard players operation #max_z bt_temp = #z2 bt_temp
# 3. Calcular dimensiones reales (size = max - min + 1)
scoreboard players operation #size_x bt_temp = #max_x bt_temp
scoreboard players operation #size_x bt_temp -= #min_x bt_temp
scoreboard players add #size_x bt_temp 1
scoreboard players operation #size_y bt_temp = #max_y bt_temp
scoreboard players operation #size_y bt_temp -= #min_y bt_temp
scoreboard players add #size_y bt_temp 1
scoreboard players operation #size_z bt_temp = #max_z bt_temp
scoreboard players operation #size_z bt_temp -= #min_z bt_temp
scoreboard players add #size_z bt_temp 1
# Guardar coordenadas exactas en storage global para exportación y uso
execute store result storage builder_tables:surveyor min_x int 1 run scoreboard players get #min_x bt_temp
execute store result storage builder_tables:surveyor min_y int 1 run scoreboard players get #min_y bt_temp
execute store result storage builder_tables:surveyor min_z int 1 run scoreboard players get #min_z bt_temp
execute store result storage builder_tables:surveyor max_x int 1 run scoreboard players get #max_x bt_temp
execute store result storage builder_tables:surveyor max_y int 1 run scoreboard players get #max_y bt_temp
execute store result storage builder_tables:surveyor max_z int 1 run scoreboard players get #max_z bt_temp
# Límite de Structure Block de Minecraft (máx 48 por eje)
execute if score #size_x bt_temp matches 49.. run tellraw @s [{"text":"[Topografía] Aviso: el ancho supera 48 bloques (límite de Bloque de Estructuras). Se delimitarán los primeros 48.","color":"yellow"}]
execute if score #size_x bt_temp matches 49.. run scoreboard players set #size_x bt_temp 48
execute if score #size_y bt_temp matches 49.. run scoreboard players set #size_y bt_temp 48
execute if score #size_z bt_temp matches 49.. run scoreboard players set #size_z bt_temp 48
# 4. Calcular posición del bloque (en la base inferior min_x, min_y - 1, min_z con offset vertical posY=1)
scoreboard players operation #sb_x bt_temp = #min_x bt_temp
scoreboard players operation #sb_y bt_temp = #min_y bt_temp
scoreboard players operation #sb_z bt_temp = #min_z bt_temp
scoreboard players set #pos_x bt_temp 0
scoreboard players set #pos_y bt_temp 1
scoreboard players set #pos_z bt_temp 0
# Si min_y > -63, colocarlo 1 bloque debajo del suelo para no sobreescribir la construcción
execute if score #min_y bt_temp matches -62.. run scoreboard players remove #sb_y bt_temp 1
# Si está en el límite inferior de la bedrock (-63 o -64), colocarlo en min_y con posY=0
execute if score #min_y bt_temp matches ..-63 run scoreboard players set #pos_y bt_temp 0
execute store result storage builder_tables:surveyor sb_x int 1 run scoreboard players get #sb_x bt_temp
execute store result storage builder_tables:surveyor sb_y int 1 run scoreboard players get #sb_y bt_temp
execute store result storage builder_tables:surveyor sb_z int 1 run scoreboard players get #sb_z bt_temp
execute store result storage builder_tables:surveyor pos_x int 1 run scoreboard players get #pos_x bt_temp
execute store result storage builder_tables:surveyor pos_y int 1 run scoreboard players get #pos_y bt_temp
execute store result storage builder_tables:surveyor pos_z int 1 run scoreboard players get #pos_z bt_temp
execute store result storage builder_tables:surveyor size_x int 1 run scoreboard players get #size_x bt_temp
execute store result storage builder_tables:surveyor size_y int 1 run scoreboard players get #size_y bt_temp
execute store result storage builder_tables:surveyor size_z int 1 run scoreboard players get #size_z bt_temp
# 5. Generar bloque de estructura en el mundo con la caja delimitadora exacta
function builder_tables_generated:surveyor/place_structure_block with storage builder_tables:surveyor
# 6. Modo creativo temporal para permitir guardar en el bloque de estructura
gamemode creative @s
playsound minecraft:block.beacon.activate player @s ~ ~ ~ 1 1.2
tellraw @s ["",{"text":"======== ","color":"dark_gray"},{"text":"[ DELIMITACIÓN DE PLANO NBT ]","color":"gold","bold":true},{"text":" ========","color":"dark_gray"}]
tellraw @s [{"text":"✔ ","color":"green","bold":true},{"text":"Caja delimitadora generada cubriendo exactamente tu obra.","color":"white"}]
tellraw @s [{"text":"• Dimensiones: ","color":"gray"},{"score":{"name":"#size_x","objective":"bt_temp"},"color":"yellow"},{"text":" x ","color":"gray"},{"score":{"name":"#size_y","objective":"bt_temp"},"color":"yellow"},{"text":" x ","color":"gray"},{"score":{"name":"#size_z","objective":"bt_temp"},"color":"yellow"},{"text":" bloques.","color":"gray"}]
tellraw @s [{"text":"• Coordenadas: ","color":"gray"},{"text":"[","color":"yellow"},{"score":{"name":"#min_x","objective":"bt_temp"},"color":"gold"},{"text":", ","color":"yellow"},{"score":{"name":"#min_y","objective":"bt_temp"},"color":"gold"},{"text":", ","color":"yellow"},{"score":{"name":"#min_z","objective":"bt_temp"},"color":"gold"},{"text":"] hasta [","color":"yellow"},{"score":{"name":"#max_x","objective":"bt_temp"},"color":"gold"},{"text":", ","color":"yellow"},{"score":{"name":"#max_y","objective":"bt_temp"},"color":"gold"},{"text":", ","color":"yellow"},{"score":{"name":"#max_z","objective":"bt_temp"},"color":"gold"},{"text":"]","color":"yellow"}]
tellraw @s [{"text":"👉 Haz clic derecho en el Bloque de Estructura, escribe el nombre y pulsa ","color":"green"},{"text":"[GUARDAR]","color":"gold","bold":true},{"text":".","color":"green"}]
tellraw @s [{"text":"📂 Se guardará en: ","color":"yellow"},{"text":".minecraft/saves/<tu_mundo>/generated/minecraft/structure/","color":"aqua"}]
tellraw @s ["",{"text":"[ 🛡 GUARDADO LISTO: RETIRAR BLOQUE Y VOLVER A SURVIVAL ]","color":"green","bold":true,"clickEvent":{"action":"run_command","value":"/trigger bt_surv_rm_sb set 1"},"hoverEvent":{"action":"show_text","contents":"Quitar el bloque blanco y regresar automáticamente al modo supervivencia"}},{"text":"  "},{"text":"[ 🛡 Volver a Survival sin retirar ]","color":"dark_green","clickEvent":{"action":"run_command","value":"/gamemode survival"},"hoverEvent":{"action":"show_text","contents":"Volver a modo supervivencia manteniendo el bloque"}}] 
tellraw @s {"text":"================================================","color":"dark_gray"}
