execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run tellraw @s {"text":"[Topografía] Falta marcar el primer punto con la Cinta.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run return 0
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run tellraw @s {"text":"[Topografía] Falta marcar el segundo punto con la Cinta.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run return 0
# 1. Obtener coordenadas de ambas esquinas marcadas más cercanas al jugador
execute store result score #x1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,sort=nearest,limit=1] Pos[0]
execute store result score #y1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,sort=nearest,limit=1] Pos[1]
execute store result score #z1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,sort=nearest,limit=1] Pos[2]
execute store result score #x2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,sort=nearest,limit=1] Pos[0]
execute store result score #y2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,sort=nearest,limit=1] Pos[1]
execute store result score #z2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,sort=nearest,limit=1] Pos[2]
# 2. Determinar min_y y max_y
scoreboard players operation #min_y bt_temp = #y1 bt_temp
scoreboard players operation #max_y bt_temp = #y2 bt_temp
execute if score #y1 bt_temp > #y2 bt_temp run scoreboard players operation #min_y bt_temp = #y2 bt_temp
execute if score #y1 bt_temp > #y2 bt_temp run scoreboard players operation #max_y bt_temp = #y1 bt_temp
# 3. Proteger Bedrock (límite inferior absoluto: Y = -63)
execute if score #min_y bt_temp matches ..-63 run scoreboard players set #min_y bt_temp -63
execute if score #max_y bt_temp < #min_y bt_temp run scoreboard players operation #max_y bt_temp = #min_y bt_temp
# 4. Guardar coordenadas en storage para la macro de demolición
execute store result storage builder_tables:surveyor x1 int 1 run scoreboard players get #x1 bt_temp
execute store result storage builder_tables:surveyor z1 int 1 run scoreboard players get #z1 bt_temp
execute store result storage builder_tables:surveyor x2 int 1 run scoreboard players get #x2 bt_temp
execute store result storage builder_tables:surveyor z2 int 1 run scoreboard players get #z2 bt_temp
scoreboard players operation #cur_y bt_temp = #min_y bt_temp
execute store result storage builder_tables:surveyor cur_y int 1 run scoreboard players get #cur_y bt_temp
# 5. Reiniciar contador de bloques y ejecutar vaciado capa por capa
scoreboard players set #total_blocks bt_temp 0
execute if score #cur_y bt_temp <= #max_y bt_temp run function builder_tables_generated:surveyor/demo_layer with storage builder_tables:surveyor
scoreboard players operation @s bt_surv_blocks = #total_blocks bt_temp
# 6. Cálculo de liquidación a 3/4 (75%) del valor en esmeraldas
# En el catálogo survival: 10 bloques estándar equivalen a 1 esmeralda base
scoreboard players set #c75 bt_temp 75
scoreboard players set #c1000 bt_temp 1000
scoreboard players operation @s bt_surv_payout = @s bt_surv_blocks
scoreboard players operation @s bt_surv_payout *= #c75 bt_temp
scoreboard players operation @s bt_surv_payout /= #c1000 bt_temp
execute if score @s bt_surv_blocks matches 1.. if score @s bt_surv_payout matches 0 run scoreboard players set @s bt_surv_payout 1
# 7. Pago de esmeraldas: hasta 64 físicas en inventario, el resto a Tarjeta Bancaria
scoreboard players operation #cash_pay bt_temp = @s bt_surv_payout
execute if score #cash_pay bt_temp matches 65.. run scoreboard players set #cash_pay bt_temp 64
execute store result storage builder_tables_generated:payment runtime.change int 1 run scoreboard players get #cash_pay bt_temp
execute if score #cash_pay bt_temp matches 1.. run function builder_tables_generated:payment/give_change with storage builder_tables_generated:payment runtime
scoreboard players operation #bank_dep bt_temp = @s bt_surv_payout
scoreboard players operation #bank_dep bt_temp -= #cash_pay bt_temp
execute if score #bank_dep bt_temp matches 1.. run scoreboard players operation @s bt_bank += #bank_dep bt_temp
# 8. Efectos sonoros y visuales de demolición
playsound minecraft:entity.generic.explode player @s ~ ~ ~ 1 0.8
playsound minecraft:block.anvil.destroy player @s ~ ~ ~ 1 1
execute at @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run particle minecraft:explosion ~ ~ ~ 2 2 2 0 10
execute at @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run particle minecraft:poof ~ ~ ~ 2 2 2 0 15
# 9. Notificación detallada al jugador
tellraw @s [{"text":"[Topografía] ","color":"gold","bold":true},{"text":"¡Área demolida y allanada exitosamente!","color":"green","bold":true}]
execute if score @s bt_surv_blocks matches 0 run tellraw @s [{"text":"[Topografía] ","color":"aqua"},{"text":"El área seleccionada ya estaba vacía (0 bloques demolidos).","color":"gray"}]
execute if score @s bt_surv_blocks matches 1.. run tellraw @s [{"text":"[Topografía] ","color":"gold"},{"text":"Bloques demolidos: ","color":"yellow"},{"score":{"name":"@s","objective":"bt_surv_blocks"},"color":"green","bold":true},{"text":" | Liquidación (75%): ","color":"yellow"},{"score":{"name":"@s","objective":"bt_surv_payout"},"color":"green","bold":true},{"text":" esmeraldas.","color":"gold"}]
execute if score #bank_dep bt_temp matches 1.. run tellraw @s [{"text":"[Banco] ","color":"dark_aqua"},{"score":{"name":"#bank_dep","objective":"bt_temp"},"color":"gold"},{"text":" esmeraldas excedentes han sido guardadas en tu Tarjeta Bancaria.","color":"aqua"}]
# 10. Limpiar esquinas
function builder_tables_generated:surveyor/clear_selection
