tag @s add bt_surv_ray_hit
kill @e[type=minecraft:marker,tag=bt_surv_c1]
summon minecraft:marker ~ ~ ~ {Tags:["bt_surv_c1"]}
execute store result score #x1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] Pos[0]
execute store result score #y1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] Pos[1]
execute store result score #z1 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] Pos[2]
particle minecraft:happy_villager ~0.5 ~1 ~0.5 0.3 0.3 0.3 0 15
