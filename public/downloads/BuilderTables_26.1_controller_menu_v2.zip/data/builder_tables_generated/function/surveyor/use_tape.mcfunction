execute if score @s bt_surv_step matches 1 run return run function builder_tables_generated:surveyor/set_corner_2
function builder_tables_generated:surveyor/set_corner_1
