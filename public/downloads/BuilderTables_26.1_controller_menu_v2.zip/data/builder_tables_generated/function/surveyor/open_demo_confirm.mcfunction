execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run tellraw @s {"text":"[Topografía] Marca el primer punto con la Cinta antes de demoler.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c1,limit=1] run return 0
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run tellraw @s {"text":"[Topografía] Marca el segundo punto con la Cinta antes de demoler.","color":"red"}
execute unless entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] run return 0
dialog show @s builder_tables:surveyor_confirm_demo
tellraw @s [{"text":"[Topografía] Haz clic aquí para: ","color":"gold"},{"text":"[ CONFIRMAR DEMOLICIÓN Y COBRAR 75% ]","color":"red","bold":true,"clickEvent":{"action":"run_command","value":"/trigger bt_surv_demo_exec set 1"},"hoverEvent":{"action":"show_text","contents":"Allana el terreno entre los 2 puntos y abona el 75% de los materiales"}}]
