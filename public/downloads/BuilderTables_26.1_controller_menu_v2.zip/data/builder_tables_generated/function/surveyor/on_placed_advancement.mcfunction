advancement revoke @s only builder_tables_generated:placed_surveyor
# Si tiene el bloque de topografía en mano principal o secundaria, activar raycast de colocación
execute if items entity @s weapon.mainhand minecraft:note_block[custom_data~{builder_tables_surveyor:1b}] run function builder_tables_generated:controller_block/ray_place
execute if items entity @s weapon.offhand minecraft:note_block[custom_data~{builder_tables_surveyor:1b}] run function builder_tables_generated:controller_block/ray_place
