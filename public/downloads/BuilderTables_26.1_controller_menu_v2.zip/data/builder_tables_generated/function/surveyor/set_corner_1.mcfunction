execute at @s run function builder_tables_generated:surveyor/ray_corner_1
scoreboard players set @s bt_surv_step 1
playsound minecraft:block.note_block.bell player @s ~ ~ ~ 1 1.6
tellraw @s [{"text":"[Topografía] ","color":"aqua","bold":true},{"text":"Punto uno seleccionado en ","color":"green","bold":true},{"text":"[","color":"yellow"},{"score":{"name":"#x1","objective":"bt_temp"},"color":"gold","bold":true},{"text":", ","color":"yellow"},{"score":{"name":"#y1","objective":"bt_temp"},"color":"gold","bold":true},{"text":", ","color":"yellow"},{"score":{"name":"#z1","objective":"bt_temp"},"color":"gold","bold":true},{"text":"]","color":"yellow"}]
