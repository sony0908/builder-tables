execute at @e[type=minecraft:marker,tag=bt_surv_sb,limit=1] run setblock ~ ~ ~ air replace
kill @e[type=minecraft:marker,tag=bt_surv_sb]
gamemode survival @s
playsound minecraft:block.fire.extinguish player @s ~ ~ ~ 0.8 1.4
tellraw @s {"text":"[Topografía] Bloque de Estructuras retirado y modo Supervivencia restaurado.","color":"gray"}
