tag @s add bt_surv_ray_hit
kill @e[type=minecraft:marker,tag=bt_surv_c2]
summon minecraft:marker ~ ~ ~ {Tags:["bt_surv_c2"]}
execute store result score #x2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] Pos[0]
execute store result score #y2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] Pos[1]
execute store result score #z2 bt_temp run data get entity @e[type=minecraft:marker,tag=bt_surv_c2,limit=1] Pos[2]
particle minecraft:wax_on ~0.5 ~1 ~0.5 0.3 0.3 0.3 0 20
