tag @s add bt_ctrl_ray_hit
execute if entity @e[type=minecraft:marker,tag=bt_surveyor_anchor,distance=..0.1,limit=1] run setblock ~ ~ ~ minecraft:note_block[note=0]
execute if entity @e[type=minecraft:marker,tag=bt_surveyor_anchor,distance=..0.1,limit=1] run function builder_tables_generated:surveyor/open
execute if entity @e[type=minecraft:marker,tag=bt_surveyor_anchor,distance=..0.1,limit=1] run return 1
execute if entity @e[type=minecraft:marker,tag=bt_plan_anchor,distance=..0.1,limit=1] run setblock ~ ~ ~ minecraft:note_block[note=0]
execute if entity @e[type=minecraft:marker,tag=bt_plan_anchor,distance=..0.1,limit=1] run function builder_tables:controller/open
